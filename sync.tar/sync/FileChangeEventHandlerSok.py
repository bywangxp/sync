from time import time

from watchdog.events import FileSystemEventHandler, os

from filedbOP import OP
from filedbOP.OP import is_ignore
from filedbOP.model import Files
from settings import local_watch_path

delete_dict = {}
add_dict = {}


class FileChangeEventHandlerSok(FileSystemEventHandler):
    def __init__(self, task):
        self.task = task
        self.change_set = set()
        self.task.setData(self.change_set)

    def on_any_event(self, event):
        src = event.src_path
        src = src[len(local_watch_path):]
        if is_ignore(src):
            return

        event_type = event.event_type
        is_directory = event.is_directory

        if not is_directory:
            print 'type:', event_type
            print 'is:', is_directory
            print 'src:', src
            src_path = os.path.join(local_watch_path, src)
            if 'move' in event_type:
                dest = event.dest_path
                print 'dest:', dest
                self.change_set.add(src)
                self.change_set.add(dest)
                dest_path = os.path.join(local_watch_path, dest)
                self.MaybeDel(src, src_path)
                self.MaybeAdd(dest, dest_path)
            else:
                self.change_set.add(src)
                self.MaybeAdd(src, src_path)

            self.task.start()
            self.task.last = time()

    def MaybeAdd(self, path, abs_path):
        if os.path.exists(abs_path):
            files = Files.select().where(Files.path == path)
            code = OP.CalcSha1(abs_path)
            if len(files) > 0:
                file = files[0]
                file.code = code
                file.ischange = True
                file.status = 2
                file.save()
            else:
                Files.create(path=path, code=code, ischange=True, status=1)
        else:
            self.MaybeDel(path, abs_path)

    def MaybeDel(self, path, abs_path):
        if not os.path.exists(abs_path):
            files = Files.select().where(Files.path == path)
            if len(files) > 0:
                file = files[0]
                file.ischange = True
                file.status = -1
                file.save()
        else:
            self.MaybeAdd(path, abs_path)
