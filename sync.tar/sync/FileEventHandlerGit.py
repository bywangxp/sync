# coding=utf-8
import socket
import threading
import time

from watchdog.events import FileSystemEventHandler

from filedbOP.OP import is_ignore
from gitOP import Git
from settings import commit_delay, push_delay, local_watch_path, branch, remote, auto_pull


class FileChangeEventHandlerGit(FileSystemEventHandler):
    last_changed = 0

    is_thread_run = False
    git = Git(local_watch_path)
    def __init__(self):
        self.git.checkout(branch)

    def notif(self, IP, PORT):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(30)
        s.connect((IP, PORT))
        s.sendall(str(time.time()))
        data = s.recv(1024)
        print data
        s.close()

    def push_callback(self):
        if auto_pull is not None:
            for name, it in auto_pull.iteritems():
                thread = threading.Thread(target=self.notif, args=(it[0], it[1],))
                thread.start()

    def git_sync(self, msg):
        time.sleep(commit_delay)
        if time.time() - self.last_changed >= commit_delay:
            self.git.add()
            self.git.commit(msg)
            print 'git commit'
            time.sleep(push_delay - commit_delay)
            if time.time() - self.last_changed >= push_delay:
                self.git.push(branch, remote)
                print 'git push'
                self.push_callback()

            self.last_changed = time.time()

        self.is_thread_run = False

    def on_any_event(self, event):
        src = event.src_path
        src = src[len(local_watch_path):]
        if is_ignore(src):
            return

        print src
        msg = 'change ' + src.replace('"', '')

        if not self.is_thread_run:
            thread = threading.Thread(target=self.git_sync, args=(msg,))
            thread.start()
            self.is_thread_run = True


