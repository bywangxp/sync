import hashlib
import os
from time import time

from filedbOP.model import Files, db
from settings import ignore_dirs, ignore_files, local_watch_path, auto_pull
from transfer.Client import Client


class DD:
    t = None

    def __init__(self):
        self.start()

    def start(self):
        self.t = time()

    def end(self, msg=''):
        dlta = time() - self.t
        print msg, ":", dlta
        self.t = time()
        return dlta


def splitList(list, max):
    for i in xrange(0, len(list), max):
        yield list[i:i + max]


def is_ignore(src):
    dirs = src.split('/')
    for p in ignore_dirs:
        for dir in dirs:
            if dir.startswith(p):
                return True
    for p in ignore_files:
        if src.endswith(p):
            return True
    return False


def getDirAllFiles(path):
    paths = []
    for root, dirs, files in os.walk(path):
        for name in files:
            file_path = os.path.join(root, name)
            file_path = file_path[len(path):]
            if is_ignore(file_path):
                continue
            paths.append(file_path.decode('utf8'))
    return paths


def getListDel(old, new):
    old = set(old)
    new = set(new)

    return list(old.difference(new))


def getListAdd(old, new):
    old = set(old)
    new = set(new)

    return list(new.difference(old))


def getListAnd(old, new):
    return list(set(old) & set(new))


def init_db():
    dd = DD()
    new_dirs = getDirAllFiles(local_watch_path)
    dd.end('get Dirs')
    codeDic = getDirAllFileHash(local_watch_path, new_dirs)
    dd.end('get Hashs')
    old_dirs = []
    old_codes = {}
    for li in Files.select():
        old_dirs.append(li.path)
        old_codes[li.path] = li.code
    dd.end('get and append')
    add_list = getListAdd(old_dirs, new_dirs)
    del_list = getListDel(old_dirs, new_dirs)
    and_list = getListAnd(old_dirs, new_dirs)

    print add_list
    print old_dirs
    print new_dirs
    # print del_list
    # print and_list

    dd.end('setOP')
    addIntoDB(add_list, codeDic)
    dd.end('add')

    delIntoDB(del_list)
    dd.end('del')

    updateIntoDB(and_list, old_codes, codeDic)
    dd.end('update')


def init_transfer():
    files = Files.select().where(Files.ischange == True)
    for key, it in auto_pull.iteritems():
        client = Client()
        client.connect(it[0], it[1])

        list = []
        update_list = []
        del_list = []
        for file in files:
            if file.status < 0:
                cmd = 'del'
                del_list.append(file.code)
            else:
                cmd = 'add'
                update_list.append(file.code)
            list.append((file.path, cmd, file.code))

        client.transferFiles(local_watch_path.decode('utf8'), list)

        for del_list_s in splitList(del_list, 999):
            Files.delete().where(Files.code << del_list_s).execute()

        for update_list_s in splitList(update_list, 499):
            query = Files.update(ischange=False, status=0).where(Files.code << update_list_s)
            query.execute()


def addIntoDB(add_list, codeDic):
    querys = []
    for li in add_list:
        querys.append({
            'path': li,
            'code': codeDic[li],
            'ischange': True,
            'status': 1
        })
    if len(querys) > 0:
        print 'add querys len:', len(querys)

        with db.atomic():
            for queryList in splitList(querys, 249):
                Files.insert_many(queryList).execute()


def delIntoDB(del_list):
    query = Files.update(ischange=True, status=-1).where(Files.path << del_list)
    query.execute()


def updateIntoDB(and_list, old_codes, codeDic):
    list = []
    for li in and_list:
        t_code = codeDic[li]
        if old_codes[li] != t_code:
            list.append((li, t_code))

    with db.atomic():
        for li in list:
            query = Files.update(code=li[1], ischange=True, status=2).where(Files.path == li[0])
            query.execute()


def getDirAllFileHash(root_dir, paths):
    start = time()
    dic = {}
    for p in paths:
        dic[p] = CalcSha1(os.path.join(root_dir, p.encode('utf8')))
    end = time()
    print end - start
    return dic


def CalcSha1(filepath):
    try:
        f = open(filepath, 'rb')
        sha1obj = hashlib.sha1()
        sha1obj.update(f.read())
        hash = sha1obj.hexdigest()
        return hash
    except IOError:
        return "0"
