# coding=utf-8
import os

from peewee import Model, CharField, SqliteDatabase, BooleanField, IntegerField

if not os.path.exists('./db'):
    os.mkdir('./db')
db = SqliteDatabase('./db/files.sqlite')


class Files(Model):
    path = CharField(primary_key=True)
    code = CharField(default='')
    ischange = BooleanField(default=True)
    # 0  无
    # 1  add
    # 2  change
    # -1 delete
    status = IntegerField(default=1)


    class Meta:
        database = db


db.connect()
if not Files.table_exists():
    db.create_table(Files)
db.close()
