import subprocess
import threading


class Git():
    def __init__(self, path):
        self.path = path

    def command(self, com):
        # print os.environ.copy(
        # env = os.environ.copy()
        # env['PATH'] += ':' + self.path
        # print env['PATH']
        com = "cd " + self.path + " && " + com

        def target():
            # print 'Thread started'
            self.process = subprocess.Popen(com, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                            )
            for line in self.process.stdout.readlines():
                print line,
            self.process.communicate()

            # print 'Thread finished'

        thread = threading.Thread(target=target)
        thread.start()

        thread.join(15)
        if thread.is_alive():
            print 'Command Timeout !'
            self.process.terminate()
            thread.join()

    def checkout(self, branch):
        self.command('git checkout ' + branch)

    def add(self):
        self.command('git add ' + '-A')

    def commit(self, msg='msg'):

        self.command('git commit -m "' + msg + '"')

    def push(self, branch, remote):

        self.command('git push ' + remote + ' ' + branch)

    def pull(self, branch, remote):
        self.command('git pull ' + remote + ' ' + branch)

    def check(self):
        self.command('git branch -v')
