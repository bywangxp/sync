# 简介
这是一个可以实时同步代码到远端机器上的工具。

你或许和我一样有这样的苦恼，本地安装项目的运行环境呕心沥血也装不好，只好在远端测试机上运行项目。但又不愿舍弃自己智能的IDE，于是辛苦用scp或git同步代码到远端，再做各种调试，效率低下，苦不堪言。

sync正是解决这些麻烦的，它使你能够自如地在本地编辑代码，在远端机调试，犹如直接在一台机器上工作。

# 安装
程序分为local端和remote端，文件是从loacl端向remote端同步的。

对于local端，需要安装一下依赖：

```
pip install -r requirements.txt
```


对于remote端，不需要安装任何依赖。

# 配置

local和remote端都需要配置根路径下的 settings.py文件，二者是共享同一个配置文件的。

程序支持两种同步方式，一种是利用自动提交git实现，另一种是直接使用socket传输文件。

因此配置文件有公共config、gitmode config、socketmode config三部分。

### commom config
- local_watch_path 本地需要同步的文件夹的路径
- remote_sync_path 同步到远端的文件夹路径
- ignore_dirs 需要忽略的路径前缀
- ignore_files 需要忽略的文件后缀
- auto_pull 一个dict，key为你需要同步的远端名称(自定义)，value为[ip,port]。支持多remote同步。
- sync_mode 'git'表示使用git方式同步，'socket'表示使用socket同步（推荐使用socket，因为用git同步的话会有很多冗余的commit，不优雅）

### git mode config （不推荐，socket 模式无需配置此部分）
- branch 用做同步的分支
- remote 用做同步的git remote
- commit_delay 无操作N秒后自动commit
- push_delay 无操作N秒后自动push

### socket mode config
- sync_delay 无操作N秒后自动同步

# 运行
### remote端
配置好后执行
/Users/xunpuwang/Documents/meituan_project/sync
python run_local.py
/home/wangxunpu/sync
python run_remote.py your_remote_name
nohup python run_remote.py stag &
```
python run_remote.py your_remote_name
```

your_remote_name为当前的remote是你在auto_pull中设置的哪个remote。例如`python run_remote.py test`

运行后会绑定你设置的相应端口，时刻监听准备同步。

**ps:** 当然，你也可以直接把它作为后台进程一直开启着:

```
nohup python run_remote.py your_remote_name &
```

这样就不用每次都手动启动了。

### local端
直接
```
python run_loacl.py
```
即可。

**注意：** 每次首次运行时，工程总文件越大，初始化耗时越长，同样的初始化传输文件时间也相对较长。**因此，最好等待初始化完成(包括传输文件完成后)再去操作文件，以防不测。**


# Todo
-  文件加密传输
-  文件忽略功能待完善
-  多线程（读文件、传文件）
-  支持同步不同路径下的文件
-  ...

