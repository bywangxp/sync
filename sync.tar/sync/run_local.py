import time

from watchdog.observers import Observer

from FileChangeEventHandlerSok import FileChangeEventHandlerSok
from FileEventHandlerGit import FileChangeEventHandlerGit
from filedbOP import OP
from settings import local_watch_path, sync_mode
from syncTask.Task import Task

if __name__ == "__main__":
    if sync_mode == 'git':
        event_handler = FileChangeEventHandlerGit()
    else:
        OP.init_db()
        OP.init_transfer()
        task = Task()
        event_handler = FileChangeEventHandlerSok(task)
    observer = Observer()
    observer.schedule(event_handler, local_watch_path, recursive=True)
    observer.start()
    try:
        while True:
            time.sleep(5000)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()
