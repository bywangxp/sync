# coding:utf-8
import SocketServer
import os
import socket
import sys

from gitOP import Git
from settings import auto_pull, branch, remote, sync_mode, remote_sync_path
from transfer.Server import MyServer

if __name__ == "__main__":

    name = sys.argv[1]

    if auto_pull is not None:
        if not os.path.exists(remote_sync_path):
            os.makedirs(remote_sync_path)
        if sync_mode == 'git':
            git = Git(remote_sync_path)
            git.pull('', '')
            git.checkout(branch)
            it = auto_pull[name]
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind(("0.0.0.0", it[1]))
            s.listen(1)
            while True:
                conn, addr = s.accept()
                print'Connected by', addr
                data = conn.recv(1024)
                git.pull(branch, remote)
                conn.sendall(name + " recv")
                conn.close()
            s.close()
        else:
            it = auto_pull[name]
            print 'Server is started\nwaiting for connection...\n'
            srv = SocketServer.ThreadingTCPServer(('0.0.0.0', it[1]), MyServer)
            srv.serve_forever()
    else:
        print 'set auto_pull frist'
