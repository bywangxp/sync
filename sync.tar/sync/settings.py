# coding=utf-8

# --------------------commom config--------------------
# 你要监控的本地文件夹的路径
local_watch_path = '/Users/xunpuwang/dpm/'

# 你要同步的远端文件夹的路径
remote_sync_path = '/home/wangxunpu/dpm/'

# 忽略的目录前缀 todo:待改进为正则匹配
ignore_dirs = ['.idea', '.git']

# 忽略的文件后缀
ignore_files = ['.pyc', '.DS_Store', '.swp']

# 远端自动pull服务设置,若不开启则为None
# key:remote_name value:[IP,port]
auto_pull = {
    "stag": ["10.32.102.254", 44392],
    # "self": ["127.0.0.1", 44392],
}

# 同步的模式 git/socket
sync_mode = 'socket'

# --------------------git mode--------------------
# 默认的分支
branch = 'cyh_master'

# 远端的名称
remote = 'origin'

# 无操作 N 秒后commit
commit_delay = 2

# 无操作 N 秒后push
push_delay = 5

# --------------------socket mode--------------------

# 无操作 N 秒后执行同步
sync_delay = 2

# --------------------format------------------------
local_watch_path = local_watch_path if local_watch_path.endswith('/') else local_watch_path + '/'
remote_sync_path = remote_sync_path if remote_sync_path.endswith('/') else remote_sync_path + '/'
