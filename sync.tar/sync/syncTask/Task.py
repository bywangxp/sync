# coding=utf-8
import threading
from time import sleep, time

from filedbOP import OP
from settings import sync_delay


class Task:
    def __init__(self):
        self.begin = False

        self.stop = True
        self.last = 0
        self.runing = False

    def start(self):
        print self.runing
        if not self.runing:
            self.thread = threading.Thread(target=self.run)
            self.runing = True
            self.thread.start()

    def setData(self, data):
        self.data = data

    def run(self):
        try:
            while True:
                if time() - self.last >= sync_delay:
                    # 干活
                    print '更新'
                    OP.init_transfer()
                    break
                sleep(0.5)
                # if self.stop:
                #     break
        except Exception, e:
            pass
        self.runing = False

    def work(self):
        for path in self.data:
            s = set()
