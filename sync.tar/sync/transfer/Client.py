# coding=utf-8
import os
import socket

buff = 8192


class Client:
    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def connect(self, ip, port):
        self.sock.connect((ip, port))

    def transferFiles(self, root, files):
        """
            files-item: (path,cmd,code)
        """
        self.sock.sendall('begin')
        res = self.sock.recv(buff)
        print res
        if res != 'ok':
            print res
            return
        self.sock.sendall(str(len(files)))
        res = self.sock.recv(buff)
        if res != 'ok':
            print res
            return

        count_byte = 0
        for path, cmd, code in files:
            if cmd == 'del':
                size = 0
            else:
                print root, path
                file_path = os.path.join(root, path)
                if os.path.exists(file_path):
                    size = os.path.getsize(file_path)
                else:
                    size = 0
                    cmd = 'del'
            txt = str(size) + '|' + path + '|' + cmd + '|'
            txt=txt.encode('utf8')
            print txt
            txt += "0" * (1000 - len(txt))
            self.sock.send(txt)
            count_byte += len(txt)
            print 'header ok'

            if cmd != 'del':
                f = open(file_path, 'rb')
                while True:
                    req = f.read(buff)
                    if req:
                        self.sock.sendall(req)
                        count_byte += len(req)
                    else:
                        f.close()
                        break

        else_byte = count_byte % buff

        self.sock.sendall('0' * buff)
        print 'for over'
        res = self.sock.recv(buff)
        print res
        if res == 'over':
            self.sock.sendall('over ok')
        self.sock.close()
