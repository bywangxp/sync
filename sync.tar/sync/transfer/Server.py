# coding=utf-8
import SocketServer
import os

from settings import remote_sync_path

buff = 8192


def doDelete(path):
    if os.path.exists(path) and os.path.isfile(path):
        os.remove(path)
    dir = os.path.split(path)[0]
    if os.path.exists(dir):
        list = os.listdir(dir)
        if len(list) == 0:
            os.rmdir(dir)
            doDelete(dir)


class MyServer(SocketServer.BaseRequestHandler):
    def handle(self):
        print 'Connected from', self.client_address
        f = open('b.txt', 'wb')
        begin = False
        status = 'no'
        while True:
            receivedData = self.request.recv(buff)
            if not receivedData:
                continue
            if receivedData == 'begin':
                begin = True
                self.request.sendall('ok')
                length = int(self.request.recv(buff))

                self.request.sendall('ok')
                file_heading = True
                last_res = ''
                count = 0
                while True:
                    # print len(last_res)
                    if len(last_res) > 1000:
                        res = ''
                    else:
                        res = self.request.recv(buff)
                    res = last_res + res
                    # 处理头部
                    if file_heading:
                        if len(res) < 1000:
                            last_res = res
                            continue
                        count += 1
                        print count, length
                        if count > length:
                            break
                        headers = res[:1000].split('|')
                        fileSize = int(headers[0])
                        path = str(headers[1])
                        cmd = str(headers[2])
                        print fileSize, path, cmd
                        file_abs_path = os.path.join(remote_sync_path, path)
                        if cmd == 'del':
                            doDelete(file_abs_path)
                        else:
                            f = FileSaver(file_abs_path)
                            cur = 0
                            file_heading = False
                        res = res[1000:]

                    # 处理文件体
                    if cmd != 'del':
                        if cur + len(res) >= fileSize:
                            # 文件读完了
                            cut = fileSize - cur
                            f.write(res[:cut])
                            f.close()

                            file_heading = True
                            last_res = res[cut:]
                        else:
                            # 文件没读完
                            # res 全都是文件体
                            cur += len(res)
                            f.write(res)
                            last_res = ''
                    else:
                        # res没有用掉,所以last_res=res
                        last_res = res
                print 'while over'
                self.request.sendall('over')

            else:
                # print receivedData
                print 'over ok'
                self.request.close()
                break

        print 'Disconnected from', self.client_address
        print


class FileSaver:
    def __init__(self, path):
        self.path = path
        self.dir = os.path.split(path)[0]
        if not os.path.exists(self.dir):
            os.makedirs(self.dir)
        self.file = open(path, 'wb')

    def write(self, data):
        self.file.write(data)

    def close(self):
        self.file.flush()
        self.file.close()
