from socket import socket


class Socket(socket):
    pass

